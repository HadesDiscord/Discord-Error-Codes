# Error Codes
All collected Discord error codes, categorized by type. See on [Userdoccers](https://docs.discord.food/datamining/errors).

## Unknown Entity
| Code | Message |
| ---- | ------- |
| 10001 | Unknown Account |
| 10002 | Unknown Application |
| 10003 | Unknown Channel |
| 10004 | Unknown Guild |
| 10005 | Unknown Integration |
| 10006 | Unknown Invite |
| 10007 | Unknown Member |
| 10008 | Unknown Message |
| 10009 | Unknown Permission Overwrite |
| 10010 | Unknown Provider |
| 10011 | Unknown Role |
| 10012 | Unknown Token |
| 10013 | Unknown User |
| 10014 | Unknown Emoji |
| 10015 | Unknown Webhook |
| 10016 | Unknown Webhook Service |
| 10017 | Unknown Connection |
| 10018 | Unknown Experiment |
| 10020 | Unknown Session |
| 10021 | Unknown Asset |
| 10023 | Unknown approval form |
| 10026 | Unknown Ban |
| 10027 | Unknown SKU |
| 10028 | Unknown Store Listing |
| 10029 | Unknown Entitlement |
| 10030 | Unknown Build |
| 10031 | Unknown Lobby |
| 10032 | Unknown Branch |
| 10033 | Unknown Store Directory Layout |
| 10035 | Unknown Price Tier |
| 10036 | Unknown Redistributable |
| 10038 | Unknown Gift Code |
| 10039 | Unknown Team |
| 10040 | Unknown Team Member |
| 10041 | Unknown Company |
| 10042 | Unknown Manifest Labels |
| 10043 | Unknown achievement |
| 10044 | Unknown EULA |
| 10045 | Unknown Application News |
| 10046 | The channel is not associated with a sku |
| 10047 | Unknown Premium Guild Subscription |
| 10048 | Unknown Gift Code Batch |
| 10049 | Unknown Stream |
| 10050 | Unknown premium server subscribe cooldown |
| 10053 | Unknown Payout |
| 10055 | Unknown Premium Guild Subscription Slot |
| 10056 | Unknown remote authentication session |
| 10057 | Unknown server template |
| 10058 | Unknown User Identity Verification |
| 10059 | Unknown discoverable server category |
| 10060 | Unknown sticker |
| 10061 | Unknown sticker pack |
| 10062 | Unknown interaction |
| 10063 | Unknown application command |
| 10064 | Unknown user trial offer |
| 10065 | Unknown Voice State |
| 10066 | Unknown application command permissions |
| 10067 | Unknown Stage Instance |
| 10068 | Unknown Guild Member Verification Form |
| 10069 | Unknown Guild Welcome Screen |
| 10070 | Unknown Guild Scheduled Event |
| 10071 | Unknown Guild Scheduled Event User |
| 10073 | Unknown Subscription Plan |
| 10075 | Unknown directory entry |
| 10076 | Unknown promotion |
| 10077 | Endpoint not available |
| 10082 | Unknown survey |
| 10083 | Unknown Server Role Subscription Settings |
| 10084 | Premium usage not available |
| 10085 | Unknown creator monetization enable request |
| 10087 | Unknown Tag |
| 10091 | Unknown Featured Item |
| 10093 | Unknown WebAuthn Authenticator |
| 10094 | Unknown User Code |
| 10095 | Unknown channel for new member action |
| 10096 | Unknown message attachment |
| 10097 | Unknown sound |
| 10099 | Unknown game invite |
| 10100 | Unknown user discount |
| 10102 | Unknown poll |
| 10105 | Unknown Snapshot |
| 10111 | Unknown Tenure Reward Status |
| 10112 | Unknown Google Play package name |
| 10113 | Guild is not a Clan |
| 10116 | Unknown Leaderboard |
| 10118 | Unknown avatar |
| 10120 | Unknown Social SDK release version |
| 10121 | Unknown Collection |
| 10124 | Unknown invite target users job |
| 10125 | Unknown Social Layer Application Storefront |
| 10126 | Unknown Wishlist |
| 10128 | Unknown Wishlist Item |
| 10129 | Unknown invite target users |
| 10131 | Unknown Tenant |
| 10132 | Unknown Layout |
| 10133 | Unknown Saved Messages |
| 10134 | UNKNOWN_TIDA_CONTENT (UNKNOWN) |
| 10135 | Unknown Template |
| 10136 | Invalid template parameters |
| 10137 | Unknown Widget Config |
| 10138 | No active partner perk activation found |
| 10139 | Unknown Conversation |
| 10141 | Unknown Vibegrations Project |
| 10142 | Unknown Guild Space |
| 10987 | Unknown Product |


## Restrictions
| Code | Message |
| ---- | ------- |
| 20001 | Bots cannot use this endpoint |
| 20002 | Only bots can use this endpoint |
| 20003 | RPC proxy disallowed |
| 20009 | Explicit content cannot be sent to the desired recipient(s) |
| 20011 | This account is scheduled for deletion |
| 20012 | You are not authorized to perform this action on this application |
| 20013 | This account is disabled |
| 20015 | This action requires a premium subscription |
| 20016 | This action cannot be performed due to slowmode rate limit |
| 20017 | The Maze isn't meant for you |
| 20018 | Only the owner of this account can perform this action |
| 20019 | You must accept the invitation to this team before you can perform this action |
| 20020 | The SKU is not available for purchase |
| 20021 | Friend list sync requires user to have verified phone |
| 20022 | This message cannot be edited due to announcement rate limits |
| 20023 | The specified local account provider is not recognized |
| 20024 | Under minimum age |
| 20025 | This action cannot be performed because the application is verified. Please contact support. |
| 20026 | This bot has been flagged by our anti-spam system for abusive behavior pending review, and is currently unable to be added to any additional servers. |
| 20027 | This action can only be performed for approved store applications |
| 20028 | The write action you are performing on the channel has hit the write rate limit. |
| 20029 | The write action you are performing on the server has hit the write rate limit |
| 20031 | Your Stage topic, server name, server description, or channel names contain words that are not allowed |
| 20032 | The write action you are performing on the channel has hit the write rate limit for messages greater than 2000 characters. |
| 20033 | This update is not allowed for this connection type |
| 20035 | Guild premium subscription level too low |
| 20037 | You must be friends with this user to perform this action |
| 20039 | This action cannot be performed because the team owns a verified application. Please contact support. |
| 20040 | This action cannot be performed because a vanity url is required for published guilds |
| 20042 | Invalid remote authentication ticket |
| 20043 | Unknown internal remote authentication error |
| 20044 | VANITY_URL_EMPLOYEE_ONLY_GUILD_DISABLED (UNKNOWN) |
| 20045 | This guild do not met requirements of using vanity url feature |
| 20049 | Invalid one time login ticket |
| 20054 | New requirements can be added only when there are no members in the role |
| 20055 | Application is restricted from joining server. See https://i.dis.gd/500 for more info. |
| 20058 | This action cannot be performed because the team has submitted identity verification. Please contact support. |
| 20060 | This application is not supported in your region. |
| 20062 | This action requires an application to be authorized by the user. |


## Resource Limitations
| Code | Message |
| ---- | ------- |
| 30001 | Maximum number of guilds reached (100) |
| 30002 | Maximum number of friends reached (1000) |
| 30003 | Maximum number of pins reached for the channel (250) |
| 30004 | Maximum number of recipients reached (10) |
| 30005 | Maximum number of guild roles reached (250) |
| 30006 | Too many users have this username, please try another |
| 30007 | Maximum number of webhooks reached (10) |
| 30008 | Maximum number of emojis reached |
| 30009 | Maximum number of connections reached (50) |
| 30010 | Maximum number of reactions reached (20) |
| 30011 | Maximum number of group DMs reached (10) |
| 30012 | Maximum number of whitelisted users reached (50) |
| 30013 | Maximum number of guild channels reached (500) |
| 30015 | Maximum number of attachments in a message reached (10) |
| 30016 | Maximum number of invites to this server reached. |
| 30017 | Maximum number of application assets reached (300) |
| 30018 | Maximum number of animated emojis reached |
| 30019 | Maximum number of server members reached (`max_members`) |
| 30021 | Maximum number of game SKUs per application reached (1). |
| 30022 | Maximum number of gifts has been reached for this SKU. |
| 30023 | Maximum number of teams reached (30) |
| 30025 | Maximum number of companies reached (20) |
| 30026 | Maximum number of premium server subscriptions reached |
| 30027 | Maximum number of user notes reached (1500) |
| 30029 | NOT_ENOUGH_GUILD_MEMBERS (UNKNOWN) |
| 30030 | Maximum number of server categories has been reached (5) |
| 30031 | Guild already has a template |
| 30032 | Maximum number of application commands reached |
| 30033 | Max number of thread participants has been reached (1000) |
| 30034 | Max number of daily application command creates has been reached (200) |
| 30035 | Maximum number of bans for non-guild members have been exceeded |
| 30037 | Max number of bans fetches has been reached. Try again later |
| 30038 | Maximum number of uncompleted guild scheduled events reached (100) |
| 30039 | Maximum number of stickers reached |
| 30040 | Maximum number of prune requests has been reached. Try again later |
| 30041 | Max number of entries in directory channel reached (500) |
| 30042 | Maximum number of guild widget settings updates has been reached. Try again later |
| 30043 | Maximum number of published tiers reached (3) |
| 30045 | Maximum number of soundboard sounds reached 36 |
| 30046 | Maximum number of edits to messages older than 1 hour reached. |
| 30047 | Maximum number of pinned threads in a forum channel has been reached |
| 30048 | Maximum number of tags in a forum channel has been reached |
| 30052 | Bitrate is too high for channel of this type |
| 30053 | Maximum total size of attachments reached 500MB. |
| 30054 | Maximum number of published application subscriptions reached (1) |
| 30055 | Maximum number of subscription group listings per type per application reached (1) |
| 30056 | Maximum number of premium emojis reached (25) |
| 30058 | Maximum number of webhooks per guild reached (1000) |
| 30059 | Maximum number of blocked users reached (5000) |
| 30060 | Maximum number of channel permission overwrites reached (1000) |
| 30061 | The channels for this guild are too large |
| 30063 | Maximum number of application subscription SKUs reached (20) |
| 30064 | Maximum number of one-time-purchase SKUs reached (50) |
| 30065 | Maximum number of published products reached (10) |
| 30066 | Maximum number of snapshot reached (5) |
| 30067 | Reached max storage capacity of snapshots |
| 30068 | Maximum number of guild integrations reached (50) |
| 30070 | Maximum message forwards reached |
| 30072 | Maximum number of store listings reached for SKU (1) |
| 30074 | Maximum number of saved messages reached |
| 30076 | Cannot publish a server subscription while a user subscription is already published. |
| 30078 | TOO_MANY_PENDING_OUTGOING (UNKNOWN) |
| 30081 | Maximum number of vibegrations projects reached |


## Rate Limits
| Code | Message |
| ---- | ------- |
| 31001 | You are being rate limited |
| 31002 | The resource is being rate limited |


## Disallowed Actions
| Code | Message |
| ---- | ------- |
| 40001 | Unauthorized |
| 40002 | You need to verify your account in order to perform this action |
| 40003 | You are opening direct messages too fast |
| 40004 | Send message has been temporarily disabled. |
| 40005 | Request entity too large |
| 40006 | This feature has been temporarily disabled |
| 40007 | The user is banned from this guild |
| 40008 | That DiscordTag is already taken |
| 40009 | Only one channel can have a parent_id modified at a time |
| 40010 | You already have a verified phone |
| 40011 | You must transfer ownership of any owned guilds before deleting your account |
| 40012 | The connection has been revoked |
| 40013 | This account must be claimed. |
| 40014 | Activity expired |
| 40015 | You must transfer ownership of any owned guilds before disabling your account |
| 40016 | Service is currently unavailable. |
| 40018 | Only consumable SKUs can be consumed |
| 40019 | Entitlement invalid for deletion |
| 40020 | SKU is restricted in your country |
| 40021 | You can't update your privacy settings at this time |
| 40024 | Team member already exists |
| 40025 | Team owner cannot be deleted |
| 40026 | All team members must have a verified email address |
| 40027 | You are already a member of this team |
| 40028 | You must transfer ownership of any owned teams before deleting your account |
| 40029 | A company with that name already exists |
| 40032 | Target user is not connected to voice. |
| 40033 | This message has already been crossposted |
| 40034 | User has disabled contact sync |
| 40035 | User identity verification processing |
| 40036 | User identity verification already succeeded |
| 40037 | Application verification ineligible |
| 40038 | Application verification already submitted |
| 40039 | Application verification already approved |
| 40041 | An application command with that name already exists |
| 40043 | Application interaction failed to send |
| 40044 | Entry already exists in this directory channel |
| 40046 | There is no outbound promotion code to claim |
| 40053 | Application must be verified to request intents |
| 40054 | Recommendations not available |
| 40058 | Cannot message this thread until after the post author has sent an initial message |
| 40060 | Interaction has already been acknowledged. |
| 40061 | Tag names must be unique |
| 40062 | Service resource is being rate limited. |
| 40064 | The application needs to be verified |
| 40066 | There are no tags available that can be set by non-moderators |
| 40067 | A tag is required to create a forum post in this channel |
| 40068 | USER_QUARANTINE (UNKNOWN) |
| 40069 | Invites are currently paused for this server. Please try again later. |
| 40071 | Users with trial subscriptions are not eligible for claiming this promotion code |
| 40073 | We could not verify your phone number. Please try again with the number listed on your account |
| 40074 | An entitlement has already been granted for this resource |
| 40075 | New member action already completed |
| 40077 | Find Friends is temporarily unavailable. |
| 40081 | Invalid recipient for friend invite |
| 40082 | Invalid code for friend invite |
| 40088 | Cannot kick the Clyde AI Bot, he can only be banned. |
| 40090 | Verified applications cannot be embedded |
| 40092 | Server is ineligible to become a Guild |
| 40094 | This interaction has hit the maximum number of follow up messages |
| 40101 | Applications with the Social Layer Integration flag enabled cannot be deleted |
| 40102 | Application has reached user threshold, will require manual review |
| 40106 | Application identity for this external account already exists for another user |
| 40108 | User is already a member of the guild |
| 40109 | User must be a member of the lobby |
| 40110 | User is not allowed to accept this invite. |
| 40113 | This application does not have multi-identity enabled and cannot use this endpoint. Please contact support if you believe this is an error. |
| 40115 | Target users file has not been processed |
| 40117 | You cannot access Discord during your restricted hours. |
| 40119 | Widget config already exists for this application |
| 40122 | An asset with that key already exists |
| 40128 | This action requires a claimed game on the application team |
| 40333 | Cloudflare access denied (code: 1020) |


## Validation Issues
| Code | Message |
| ---- | ------- |
| 50001 | Missing Access |
| 50002 | Invalid account type |
| 50003 | Cannot execute action on a DM channel |
| 50004 | Widget Disabled |
| 50005 | Cannot edit a message authored by another user |
| 50006 | Cannot send an empty message |
| 50007 | Cannot send messages to this user |
| 50008 | Cannot send messages in a non-text channel |
| 50009 | Channel verification level is too high |
| 50010 | OAuth2 application does not have a bot |
| 50011 | OAuth2 application limit reached |
| 50012 | Invalid OAuth State |
| 50013 | Missing Permissions |
| 50014 | Invalid authentication token |
| 50015 | Note was too long |
| 50016 | Provided too few or too many messages to delete. Must provide at least 2 and fewer than 100 messages to delete. |
| 50017 | Invalid MFA Level |
| 50018 | Password does not match |
| 50019 | A message can only be pinned to the channel it was sent in |
| 50020 | Invite code was either invalid or taken |
| 50021 | Cannot execute action on a system message |
| 50022 | Invalid phone number |
| 50023 | Invalid client id |
| 50024 | Cannot execute action on this channel type |
| 50025 | Invalid OAuth2 access token |
| 50026 | Missing required OAuth2 scope |
| 50027 | Invalid webhook token provided |
| 50028 | Invalid role |
| 50029 | Users without verified emails cannot be added to the application whitelist |
| 50030 | You cannot invite yourself to the application whitelist |
| 50031 | You cannot invite a user who was already whitelisted, or is already a member |
| 50033 | Invalid Recipient(s) |
| 50034 | A message provided was too old to bulk delete |
| 50035 | Invalid Form Body |
| 50036 | You cannot accept an invite to a server that the application’s bot is not in. |
| 50037 | Verification code is invalid |
| 50038 | You cannot perform this action on yourself |
| 50039 | Invalid Activity Action |
| 50040 | Invalid OAuth2 redirect_uri |
| 50041 | Invalid API version provided |
| 50042 | Invalid Billing State |
| 50043 | Data Harvest is pending, another Data Harvest cannot be started |
| 50044 | Data Harvest can only be requested every 30 days |
| 50045 | File uploaded exceeds the maximum size |
| 50046 | Invalid Asset |
| 50048 | Invalid Payment Source |
| 50049 | Invalid IP Address. Only IPv4 Addresses are supported |
| 50050 | This gift has been redeemed already. |
| 50051 | You already own this SKU. |
| 50054 | Cannot self-redeem this gift |
| 50055 | Invalid Guild |
| 50056 | Cannot delete asset that is currently in use on a store page |
| 50057 | Invalid SKU |
| 50058 | Cannot apply licence to an application that is already activated |
| 50059 | Application cannot be submitted for approval. Please refer to the developer checklist. |
| 50060 | Invalid application store state. |
| 50061 | A branch needs to be associated with the channel to use this endpoint |
| 50064 | Cannot unsubscribe from a server again |
| 50067 | Invalid request origin |
| 50068 | Invalid message type |
| 50069 | Must wait for premium server subscription cooldown to expire |
| 50070 | Payment source required to redeem gift |
| 50071 | New subscription required to redeem gift |
| 50073 | Cannot modify a system webhook |
| 50074 | Cannot delete a channel required for Community guilds |
| 50080 | Cannot edit stickers within a message |
| 50081 | Cannot use this sticker |
| 50083 | Thread is archived |
| 50084 | Invalid thread notification settings |
| 50085 | `before` value is earlier than the thread creation date |
| 50086 | Community server channels must be text channels |
| 50089 | Event cannot be started for this channel |
| 50090 | Cannot start an event that is active or completed |
| 50091 | The entity type of the event is different from the entity you are trying to start the event for |
| 50092 | You have already owned this SKU |
| 50094 | Invalid directory entry type |
| 50095 | This server is not available in your location |
| 50096 | Cannot accept your own friend invite |
| 50097 | Cannot redeem gift |
| 50099 | This entity can only be edited through the server settings UI |
| 50101 | This server needs more boosts to perform this action |
| 50102 | Cannot update price tier on a published role listing |
| 50104 | Malformed user settings payload |
| 50105 | User Settings failed validation: {reason} |
| 50106 | You do not have access to the requested activity |
| 50107 | This server needs more boosts to launch this activity |
| 50108 | INVALID_ACTIVITY_LAUNCH_CONCURRENT_ACTIVITIES (UNKNOWN) |
| 50109 | The request body contains invalid JSON. |
| 50110 | The provided file is invalid. |
| 50111 | Invalid guild join request application status query |
| 50112 | Cannot delete a subscription group that has listings |
| 50113 | Cannot create more than 1 subscription group |
| 50119 | This guild is not allowed to use monetization features. |
| 50121 | This server is not eligible to request monetization |
| 50123 | The provided file type is invalid. |
| 50124 | The provided file duration exceeds maximum of 5.2 seconds. |
| 50129 | You must have Nitro to launch this activity |
| 50131 | Owner cannot be pending member |
| 50132 | Ownership cannot be transferred to a bot user |
| 50133 | User is already owner |
| 50136 | User does not have access to private channel. |
| 50138 | Failed to resize asset below the maximum size: 262144 |
| 50139 | User could not be found. |
| 50140 | User is not staff |
| 50144 | Cannot mix subscription and non subscription roles for an emoji |
| 50145 | Cannot convert between premium emoji and normal emoji. |
| 50146 | Uploaded file not found |
| 50147 | Invalid connection |
| 50148 | Cannot launch Activity in AFK Channel |
| 50150 | Invalid Role Configuration |
| 50151 | The specified emoji is invalid |
| 50152 | This server is not eligible for store pages |
| 50155 | This server is not allowed to create an enable request |
| 50157 | Cannot delete a subscription listing with subscriptions |
| 50158 | Onboarding responses are not valid |
| 50159 | Voice messages do not support additional content |
| 50160 | Voice messages must have a single audio attachment |
| 50161 | Voice messages must have supporting metadata |
| 50162 | Voice messages cannot be edited |
| 50163 | Cannot delete guild subscription integration |
| 50164 | New owner is ineligible for server subscription requirement |
| 50165 | Cannot launch Age-Gated Activity |
| 50166 | Only discoverable servers can publish a landing page |
| 50167 | Cannot send soundboard sound when user is server muted, deafened, or suppressed |
| 50168 | User must be in voice channel to send voice channel effect |
| 50169 | Cannot update other guild fields when disabling invites. |
| 50170 | Cannot specify channel_id and guild_id |
| 50171 | This action cannot be performed because at least one tier exists. |
| 50173 | Cannot send voice messages in this channel |
| 50174 | Not a valid clip |
| 50178 | The user account must first be verified |
| 50179 | Only media channel post can have preview |
| 50182 | Cannot set hide media download option flag for non media channels |
| 50183 | Only Community Servers can create permanent invite links. |
| 50184 | User is not eligible for sending remix |
| 50186 | Archive files are not supported: {filename} |
| 50187 | Unable to validate domain. |
| 50188 | Invalid guild feature |
| 50191 | Application is unable to monetize |
| 50192 | The provided file does not have a valid duration. |
| 50193 | This promotion is invalid. |
| 50194 | This gift code belongs to someone else. |
| 50196 | Guilds cannot be specified for user installation |
| 50197 | Invalid scopes provided for user installation |
| 50199 | Installation type not supported for this application |
| 50205 | In-app appeals are not supported for this violation type. |
| 50206 | Maximum number of user-installed applications reached (200) |
| 50209 | You cannot launch this activity in a server with more than 25 members |
| 50220 | Activity location is invalid |
| 50223 | Each application can only have one primary entry point application command |
| 50225 | Activity ID is invalid |
| 50226 | PRIMARY_ENTRY_POINT app commands must have APP_HANDLER handler if app has no activity |
| 50228 | Cannot adopt tag for this guild |
| 50229 | Invalid user type |
| 50230 | Activities cannot be launched on user’s current client platform |
| 50231 | ACTIVITY_CONFIGURATION_DOES_NOT_SUPPORT_PLATFORM (UNKNOWN) |
| 50232 | Activity failed to launch due to internal error |
| 50235 | Invalid channel for lobby channel linking |
| 50237 | Channel is already linked to another lobby |
| 50239 | Rules and public updates channels are only available for community guilds |
| 50240 | You cannot remove this app's Entry Point command in a bulk update operation. Please include the Entry Point command in your update request or delete it separately. |
| 50241 | User does not have the necessary lobby permissions to perform this action |
| 50242 | Cannot set reminder in the past |
| 50243 | Due date must be in less than 5 years |
| 50251 | Recipient does not allow messages from game friends in Discord |
| 50252 | Provisional accounts cannot recieve messages while offline |
| 50253 | Ephemeral messages cannot be sent to offline users |
| 50255 | Invalid voice filter module version |
| 50258 | Child applications cannot perform this action |
| 50260 | Application is not a child application |
| 50262 | Role is too large to be displayed separately from online members |
| 50264 | Permission migration unavailable |
| 50265 | Permission already migrated |
| 50266 | Invalid Tenor media format |
| 50267 | Lobby is not linked to a channel |
| 50269 | Missing access to age-gated content |
| 50270 | Invite is expired |
| 50272 | Thread does not have enough messages to generate a summary |
| 50277 | The application name is invalid. |
| 50278 | Cannot send messages to this user due to having no mutual guilds |
| 50279 | Your TikTok profile name has leading or trailing spaces. Update your profile name on TikTok and try again. |
| 50280 | CONNECTION_RATELIMITED (UNKNOWN) |
| 50281 | Config is not published |
| 50283 | INVALID_GIFT_REDEMPTION_CLIENT_UPDATE_REQUIRED (UNKNOWN) |
| 50284 | Invalid application |
| 50287 | Unknown game |
| 50291 | Scheduled storefronts are not enabled for this application |
| 50600 | You do not have permission to send this sticker. |


## Multi-Factor Authentication
| Code | Message |
| ---- | ------- |
| 60001 | This account is already enrolled in two factor authentication |
| 60002 | This account is not enrolled in two factor authentication |
| 60003 | Two factor is required for this operation |
| 60004 | Must be a verified account |
| 60005 | Invalid two-factor secret |
| 60006 | Invalid two-factor auth ticket |
| 60008 | Invalid two-factor code / Security key authentication failed |
| 60009 | Invalid two-factor session |
| 60010 | This account is not enrolled in SMS authentication |
| 60011 | Invalid key |
| 60012 | SMS Two-factor authentication cannot be enabled on this account |
| 60015 | Multi-factor authentication is required for administrators of servers with published Server Shop listings. |
| 60019 | User is not eligible for MFA Email Verification. |
| 60021 | Credential not discoverable or invalid |


## Phone Numbers
| Code | Message |
| ---- | ------- |
| 70003 | Unable to send sms message |
| 70004 | This phone number was recently used on a different account |
| 70005 | Please use a valid mobile phone number, not a VoIP or landline number. |
| 70007 | You need to verify your phone number in order to perform this action. |
| 70008 | An existing Discord account is already using this number. Please remove it before it can be used with a new account. |
| 70009 | Your Discord password reset link was sent to your email. Please check your email to reset your password. |
| 70011 | This phone number is unable to be associated with this account. To troubleshoot please go here: https://dis.gd/phone-errors |


## Relationships
| Code | Message |
| ---- | ------- |
| 80000 | Incoming friend requests disabled |
| 80001 | Friend request blocked |
| 80002 | Bots cannot have friends |
| 80003 | Cannot send friend request to self |
| 80004 | No users with DiscordTag exist |
| 80005 | You do not have an incoming friend request from that user |
| 80006 | You need to be friends in order to make this change. |
| 80007 | You are already friends with that user. |
| 80008 | You must include a discriminator. |
| 80009 | Users have no common application authorization |
| 80011 | A user is no longer authorized with this application |
| 80013 | You must confirm the friend request to add this user. |


## Blocked Actions
| Code | Message |
| ---- | ------- |
| 90001 | Reaction was blocked |
| 90002 | User cannot use burst reactions |
| 90003 | No available burst currency for user |
| 90004 | Invalid reaction type |
| 90100 | Invalid update for Message Request |


## Billing
| Code | Message |
| ---- | ------- |
| 100001 | UNKNOWN_BILLING_PROFILE (UNKNOWN) |
| 100002 | Invalid payment source |
| 100003 | Invalid subscription |
| 100004 | Already subscribed |
| 100005 | Invalid plan |
| 100006 | Payment source required |
| 100007 | Already canceled |
| 100008 | Invalid payment |
| 100009 | Already refunded |
| 100010 | Billing address is invalid |
| 100011 | Already purchased |
| 100012 | You already have a purchase in progress for this item. |
| 100015 | Valid dependent SKU entitlement is required |
| 100017 | This purchase request is invalid |
| 100018 | A payment is required |
| 100019 | User is ineligible for trial |
| 100021 | Invalid Apple Receipt |
| 100022 | GIFTING_CANT_REDEEM_SUBSCRIPTION_MANAGED (UNKNOWN) |
| 100023 | INVALID_GIFT_REDEMPTION_SUBSCRIPTION_INCOMPATIBLE (UNKNOWN) |
| 100024 | INVALID_GIFT_REDEMPTION_INVOICE_OPEN (UNKNOWN) |
| 100025 | GIFTING_CANT_REDEEM_INVOICE_OPEN (UNKNOWN) |
| 100026 | The purchase amount is below the minimum charge amount. |
| 100027 | Invoice amount cannot be negative. |
| 100029 | Authentication required |
| 100031 | There is already a payment in progress |
| 100034 | Invalid subscription item |
| 100035 | This trial subscription cannot be modified |
| 100037 | Subscription items are required |
| 100038 | Cannot preview this subscription update |
| 100039 | All subscription items must have the same interval |
| 100040 | Invalid subscription_items |
| 100042 | Subscription renewal is in progress |
| 100046 | Invalid price tier order |
| 100047 | Confirmation required |
| 100048 | Could not process this refund. Please contact support. |
| 100051 | Invalid currency for payment |
| 100052 | Invalid currency for subscription plan |
| 100053 | Ineligible for subscription |
| 100054 | The card was declined. |
| 100055 | Pending purchase could not be verified. |
| 100056 | This client needs to be authorized for purchases. We've sent you an email. Click the link on the email and then retry the purchase. |
| 100058 | This payment method cannot be used |
| 100059 | Open invoice not found. |
| 100060 | Non refundable payment source |
| 100062 | Subscription metadata is invalid |
| 100066 | Currency cannot be changed without a payment source |
| 100069 | Invalid operation |
| 100070 | BILLING_APPLE_SERVER_API_ERROR (UNKNOWN) |
| 100071 | User is not eligible for creating referrals |
| 100076 | Error while generating PDF |
| 100078 | BILLING_TRIAL_REDEMPTION_DISABLED (UNKNOWN) |
| 100079 | Pause is temporarily unavailable. Please try again later. |
| 100080 | Pause is already pending. |
| 100081 | Subscriptions not eligible for pause. |
| 100082 | Invalid pause interval. |
| 100083 | BILLING_ALREADY_PAUSED (UNKNOWN) |
| 100084 | BILLING_CANNOT_CHARGE_ZERO_AMOUNT (UNKNOWN) |
| 100086 | Discount not available for redemption. |
| 100089 | Entitlement already fulfilled. |
| 100094 | Invalid update for paused or pause pending subscription. |
| 100095 | Pause subscription is not available for this plan |
| 100096 | Bundle already purchased. |
| 100097 | Bundle already partially owned. |
| 100103 | Invalid purchase token |
| 100106 | Discord has stopped accepting payments through Sofort. Please add another payment method. |
| 100107 | There aren't enough funds to complete the purchase. Please check your balance or try a different payment method. |
| 100111 | Invalid parameters provided in request |
| 100123 | BILLING_SUBSCRIPTION_GROUP_MAX_MEMBERS (UNKNOWN) |
| 100124 | BILLING_SUBSCRIPTION_GROUP_USER_INELIGIBLE (UNKNOWN) |
| 100125 | BILLING_SUBSCRIPTION_GROUP_INVITE_ALREADY_ACCEPTED (UNKNOWN) |
| 100126 | BILLING_SUBSCRIPTION_GROUP_USER_IS_BOT (UNKNOWN) |
| 100127 | BILLING_SUBSCRIPTION_GROUP_USER_ALREADY_IN_GROUP (UNKNOWN) |
| 100128 | BILLING_SUBSCRIPTION_GROUP_USER_HAS_FRACTIONAL_NITRO (UNKNOWN) |
| 100129 | BILLING_SUBSCRIPTION_GROUP_USER_BOOST_ONLY (UNKNOWN) |
| 100130 | BILLING_SUBSCRIPTION_GROUP_USER_ACCOUNT_TOO_YOUNG (UNKNOWN) |
| 100131 | BILLING_SUBSCRIPTION_GROUP_USER_HAS_INELIGIBLE_PLAN (UNKNOWN) |
| 100132 | BILLING_SUBSCRIPTION_GROUP_USER_ON_COOLDOWN (UNKNOWN) |
| 100133 | BILLING_SUBSCRIPTION_GROUP_USER_ACTIVE_BOOSTS (UNKNOWN) |
| 100135 | User with gift subscription cannot join premium group subscriptions |
| 100136 | BILLING_SUBSCRIPTION_GROUP_USER_HAS_MOBILE_SUBSCRIPTION (UNKNOWN) |
| 100137 | BILLING_SUBSCRIPTION_GROUP_USER_INVALID_SUBSCRIPTION (UNKNOWN) |
| 100138 | Unknown Order |
| 100144 | Currency not allowed for country |
| 100145 | Billing address country is not allowed for your store country |
| 100149 | Payment source is not available for checkout |
| 100150 | This purchase will exceed your monthly spending limit. |
| 100151 | Your monthly spending limit has been reached. |
| 100152 | Order is no longer signable. Please reopen checkout. |
| 100155 | Claim your existing purchase in-game to buy this again. |


## Pending Resources
| Code | Message |
| ---- | ------- |
| 110000 | Index not yet available. Try again later |
| 110001 | Application not yet available. Try again later |


## LFG Channels
| Code | Message |
| ---- | ------- |
| 120000 | LISTING_ALREADY_JOINED (UNKNOWN) |
| 120001 | LISTING_TOO_MANY_MEMBERS (UNKNOWN) |
| 120002 | LISTING_JOIN_BLOCKED (UNKNOWN) |


## API Resources
| Code | Message |
| ---- | ------- |
| 130000 | This resource is currently overloaded, and thus too busy to serve requests |


## Achievements
| Code | Message |
| ---- | ------- |
| 140000 | Maximum number of achievements reached (1000) |


## Applications / Requests
| Code | Message |
| ---- | ------- |
| 150001 | Server does not pass partner requirements |
| 150002 | You must revoke your existing request to join before re-applying |
| 150003 | Cannot find a pending application for this user |
| 150004 | You already have a pending Partner application |
| 150006 | The Stage is already open |
| 150008 | You cannot acknowledge this join request |
| 150009 | This user is already a member, join request is already closed |
| 150011 | Server must raise verification level in order to perform this action |
| 150016 | Join request not found |
| 150018 | You do not have permission to see this join request |
| 150019 | You cannot create or join an interview for this join request. |
| 150020 | Join request interviews are not available for this guild. |
| 150022 | Join request interview is full. |
| 150023 | User is not eligible to join this server. |
| 150024 | You must wait another 7 day(s) before applying to this server again. |
| 150027 | User is not allowed to speak on stages |


## Chat Limitations
| Code | Message |
| ---- | ------- |
| 160002 | Cannot reply without permission to read message history |
| 160004 | A thread has already been created for this message |
| 160005 | Thread is locked |
| 160006 | Maximum number of active threads reached |
| 160007 | Maximum number of active announcement threads reached |
| 160008 | Message could not be found |
| 160009 | Cannot reference a message without permission to read message history |
| 160010 | NSFW channel message reference not allowed |
| 160011 | Forward messages cannot have additional content |
| 160012 | Forward message not allowed for monetised channel |
| 160014 | You cannot forward a message whose content you cannot read |


## Guild Stickers
| Code | Message |
| ---- | ------- |
| 170001 | Invalid JSON for uploaded Lottie file |
| 170002 | Uploaded Lotties cannot contain rasterized images such as PNG or JPEG |
| 170003 | Sticker maximum framerate exceeded |
| 170004 | Sticker frame count exceeds maximum of 1000 frames |
| 170005 | Sticker maximum dimensions exceeded |
| 170006 | Sticker frame rate is either too small or too large |
| 170007 | Sticker animation duration exceeds maximum of 5 seconds |
| 170008 | Poggermode has been temporarily disabled. |


## Guild Events
| Code | Message |
| ---- | ------- |
| 180000 | Cannot update a finished event |
| 180001 | Exactly one guild_id query parameter is required |
| 180002 | Failed to create stage needed for stage event |
| 180003 | You must join the server to take this action |
| 180004 | This route requires a recurring event |
| 180005 | Recurring event exceptions must have a modified event field from the event series |
| 180006 | Cannot RSVP to a finished event |


## Guild Verification
| Code | Message |
| ---- | ------- |
| 181000 | We are temporarily not accepting Verified Server Applications while we tidy up things on our end. |


## Application Verification
| Code | Message |
| ---- | ------- |
| 190001 | All apps must have a privacy policy. |
| 190002 | All apps must have a Terms of Service. |
| 190003 | This application is not currently in the minimum number of servers required for intent verification. Please try again once in 75 servers. |
| 190005 | No official server found |
| 190006 | Multiple official servers found |
| 190008 | Official server owner not on team |
| 190009 | Official server owner two-factor authentication not enabled |
| 190015 | You cannot request a retry or to resend the verification code if you are providing a verification code |
| 190016 | Unknown application game claim |
| 190018 | You must provide your full name and business email when verifying a game claim |


## Auto Moderation
| Code | Message |
| ---- | ------- |
| 200000 | This can't be posted because it contains content blocked by this community. This may also be viewed by the community owners. |
| 200001 | This can't be sent because it contains content blocked by this community. Please revise and try again. |
| 200002 | Regex validation service unavailable. Please try again later. |
| 200005 | You cannot join this server because your username contains content blocked by this server. |


## Guild Monetization
| Code | Message |
| ---- | ------- |
| 210000 | Monetization request has not been approved yet |
| 210001 | The terms for monetization request have already been acked |
| 210002 | Cannot access application |
| 210003 | The terms for monetisation have not been accepted |
| 210011 | TWO_FA_NOT_ENABLED (UNKNOWN) |
| 210019 | Your monetization requirements are in an unexpected state. Please contact support. |
| 210020 | You are running old code. Please restart your app. |
| 210021 | Cannot publish a product without a benefit |
| 210026 | CREATOR_MONETIZATION_PAYMENT_TEAM_REQUIRED (UNKNOWN) |
| 210027 | Must complete setup and verification of payment account |
| 210028 | Payout account is not located in a currently-supported country |


## Webhooks
| Code | Message |
| ---- | ------- |
| 220001 | Webhooks posted to forum channels must have a thread_name or thread_id |
| 220002 | Webhooks posted to forum channels cannot have both a thread_name and thread_id |
| 220003 | Webhooks can only create threads in forum channels |
| 220004 | Webhook services cannot be used in forum channels |


## Guild Home
| Code | Message |
| ---- | ------- |
| 230000 | Items in this channel cannot be featured |


## Harmful Links Filter
| Code | Message |
| ---- | ------- |
| 240000 | Message blocked by harmful links filter |


## Drops / Quests
| Code | Message |
| ---- | ------- |
| 260000 | User is not enrolled in the given quest |
| 260001 | User has not completed the given drop |
| 260002 | Unable to claim code for the given quest |
| 260003 | User has already claimed code for the given drop |
| 260004 | Quest does not support codes for this platform |
| 260008 | Unknown quest |
| 260010 | User has already claimed a reward for the given quest |
| 260012 | User is not a previewer for the quest |
| 260013 | Upload link is invalid or expired |
| 260015 | Upload link code is malformed |
| 260017 | Quest has expired |
| 260018 | User is not eligible for bounties |
| 260019 | Looks like you already claimed the reward for this bounty recently. Please refresh your client and try again later. |


## External Integrations
| Code | Message |
| ---- | ------- |
| 270000 | CONSOLE_DEVICE_PASSCODE_UNLOCK_REQUIRED (UNKNOWN) |
| 270001 | CONSOLE_DEVICE_UNAVAILABLE (UNKNOWN) |
| 270002 | CONSOLE_DEVICE_UNVAILABLE_FROM_OTHER_USERS (UNKNOWN) |
| 270003 | CONSOLE_DEVICE_COMMUNICATION_RESTRICTED (UNKNOWN) |
| 270004 | CONSOLE_DEVICE_INVALID_POWER_MODE (UNKNOWN) |
| 270005 | CONSOLE_DEVICE_ACCOUNT_LINK_ERROR (UNKNOWN) |
| 270006 | CONSOLE_DEVICE_MAX_MEMBERS_REACHED (UNKNOWN) |
| 270007 | CONSOLE_DEVICE_BAD_COMMAND (UNKNOWN) |
| 270008 | Application does not meet activity requirements |


## Providers (Two-way Linking)
| Code | Message |
| ---- | ------- |
| 280000 | This provider does not support two-way linking |
| 280001 | This provider does not support device code flow two-way linking. |
| 280002 | Missing two-way user code. |
| 280003 | User not authorized to create provider. |
| 280004 | Invalid success_reidrect. |


## Family Center
| Code | Message |
| ---- | ------- |
| 290000 | User is not eligible for parent tools. |
| 290001 | No link currently exists between users |
| 290002 | Too many links exist for one of the requested users |
| 290003 | User link status cannot transition from current state to desired state. |
| 290004 | Teens cannot request an activity view for other users in family center |
| 290005 | A link request already exists between the two users |
| 290006 | A linking code has not been generated for this use |
| 290007 | The linking code is invalid or has expired |
| 290008 | Invalid user settings update |


## Clyde AI
| Code | Message |
| ---- | ------- |
| 310000 | Clyde consent is required |
| 310002 | You are sending too many messages to Clyde. Try again later |
| 310003 | This backstory could result in potentially unsafe or harmful responses.  Please modify the backstory and try again. |
| 310006 | Clyde Profile Not found |


## User Limitations
| Code | Message |
| ---- | ------- |
| 340001 | Access to sending messages in guild channels has been limited for the user |
| 340002 | Access to sending DMs has been limited for the user |
| 340003 | Access to sending messages in group DMs has been limited for the user |
| 340004 | Access to uploading attachments to guilds has been limited for the user |
| 340005 | Access to uploading attachments to DMs has been limited for the user |
| 340006 | Access to uploading attachments to group DMs has been limited for the user |
| 340007 | Access to sending friend request has been limited for the user |
| 340009 | Access to creating new guilds has been limited for the user |
| 340013 | Access to sending messages in server channels has been limited for the user |
| 340014 | Access to uploading attachments to servers has been limited for the user |
| 340015 | Access to joining new servers has been limited for the user |
| 340016 | Access to creating new servers has been limited for the user |
| 340017 | Access to creating new server text channels has been limited for the user |
| 340018 | Access to creating new server voice channels has been limited for the user |


## Guild Onboarding
| Code | Message |
| ---- | ------- |
| 350000 | Cannot enable onboarding, requirements are not met |
| 350001 | Cannot update onboarding while below requirements |
| 350002 | Cannot update responses. You must complete pre-join onboarding first. |
| 350003 | Onboarding channels must be readable by everyone |
| 350004 | This application is not allowed for onboarding connections in this guild. |


## Conversation Summaries
| Code | Message |
| ---- | ------- |
| 360000 | Server is ineligible for summaries. |
| 360001 | Channel is ineligible for summaries. |


## Guest Invites
| Code | Message |
| ---- | ------- |
| 380000 | Cannot join because you are on a timeout |


## Emoji Inventory
| Code | Message |
| ---- | ------- |
| 390001 | Pack not found |
| 390002 | Must provide a pack id |
| 390003 | Inventory not enabled |
| 390004 | Inventory settings not enabled |
| 390010 | Inventory pack limit reached |
| 390011 | Inventory pack has no contents |


## Guild Limitations
| Code | Message |
| ---- | ------- |
| 400000 | Token is invalid. |
| 400001 | Access to file uploads has been limited for this server |
| 400002 | Access to inviting new users through invite links has been limited for this guild |
| 400003 | GUILD_GO_LIVE_LIMITED_ACCESS (UNKNOWN) |
| 400005 | GUILD_MESSAGE_UPDATE_RATE_LIMIT_EXCEEDED (UNKNOWN) |


## Game Invites
| Code | Message |
| ---- | ------- |
| 410001 | You cannot invite this user |


## Partner Promotions
| Code | Message |
| ---- | ------- |
| 420002 | User has already claimed promotion. |
| 420003 | PARTNER_PROMOTIONS_MAX_CLAIMS (UNKNOWN) |
| 420004 | Gift already claimed. |
| 420005 | Previous purchase error. |
| 420006 | New subscription required. |
| 420007 | Unknown gift. |


## Guild Bans
| Code | Message |
| ---- | ------- |
| 500000 | Failed to ban users |


## Polls
| Code | Message |
| ---- | ------- |
| 520000 | Poll voting blocked |
| 520001 | Poll expired |
| 520002 | Cannot create a poll in this type of channel |
| 520003 | Cannot edit a poll message |
| 520004 | Cannot use one or more emoji included with this poll |
| 520006 | Cannot expire a message that is not a poll |
| 520007 | Poll has already expired |


## Reports
| Code | Message |
| ---- | ------- |
| 521001 | DSA_RSL_REPORT_NOT_FOUND (UNKNOWN) |
| 521002 | DSA_RSL_ALREADY_REQUESTED (UNKNOWN) |
| 521003 | DSA_RSL_LIMITED_TIME (UNKNOWN) |
| 521004 | DSA_RSL_REPORT_INELIGIBLE (UNKNOWN) |


## Appeals
| Code | Message |
| ---- | ------- |
| 522001 | DSA_APPEAL_REQUEST_DEFLECTION (UNKNOWN) |
| 522002 | Internal error occurred while processing the appeal |


## Game Discovery
| Code | Message |
| ---- | ------- |
| 524000 | Unknown game for discovery |


## Social Layer SDK
| Code | Message |
| ---- | ------- |
| 530000 | Application is not configured to use the Partner SDK |
| 530001 | Token is past expiration |
| 530002 | Token issuer is incorrect |
| 530003 | Token audience is incorrect |
| 530004 | Token was issued too long ago |
| 530006 | Username generation failed |
| 530007 | Invalid client |
| 530008 | OIDC configuration not found |
| 530009 | OIDC JWKS not found |
| 530010 | User account is non-provisional and should be authed through OAuth2 |
| 530012 | OIDC JWKS is not valid: {reason} |
| 530014 | Invalid merge source |
| 530016 | Invalid merge destination |
| 530017 | Merge source user banned |
| 530020 | OIDC JWT id token is invalid |
| 530022 | Token project_id doesn't match the application's configured Unity project ID |
| 530023 | This user already has an associated external identity |
| 530027 | Missing `kid` header |


## DAVE
| Code | Message |
| ---- | ------- |
| 560000 | Public key must be present |
| 560001 | Public key was not in expected format |
| 560003 | Public key self-signature was invalid |
| 560004 | Public key is not unique |
| 560006 | Content inventory entry cannot be shared to this channel |


## Lobbies
| Code | Message |
| ---- | ------- |
| 570001 | Channels linked to lobbies cannot be age-restricted |


## Voice Hangout
| Code | Message |
| ---- | ------- |
| 575001 | Image is too large. Please try a smaller file. |
| 575002 | That image URL is not supported. |
| 575003 | Could not download the image. Please try again. |
| 575004 | That file is not a supported image format. |


## Virtual Currency
| Code | Message |
| ---- | ------- |
| 590001 | Insufficient balance |
| 590005 | This SKU does not have a virtual currency price. |
| 590008 | Something went wrong |
| 590009 | The gift card has already been redeemed. |
| 590010 | This item must be purchased with fiat currency. |


## Account Revert
| Code | Message |
| ---- | ------- |
| 620000 | Invalid token |
| 620001 | ACCOUNT_REVERT_EMAIL_ALREADY_TAKEN (UNKNOWN) |
| 620002 | ACCOUNT_REVERT_ACCOUNT_NOT_FOUND (UNKNOWN) |


## Guild Discovery
| Code | Message |
| ---- | ------- |
| 630001 | Invalid search query |


## Message Potions
| Code | Message |
| ---- | ------- |
| 650003 | User does not have the necessary permission |


## Subscriptions Rewards
| Code | Message |
| ---- | ------- |
| 660001 | Subscription is ineligible for this campaign |


## Guild Powerups
| Code | Message |
| ---- | ------- |
| 670001 | Unable to find entitlement |
| 670002 | Cannot deactivate entitlement |
| 670003 | Entitlement purchase limit reached |
| 670004 | Dependent entitlement not found |
| 670005 | Insufficient boosts |
| 670006 | Missing guild feature |
| 670007 | Premium tier 3 override is active |
| 670008 | Invalid role color |


## Restrictions
| Code | Message |
| ---- | ------- |
| 680009 | This Application has been flagged for abusive behavior pending review, and is currently unable to be authorized to any additional servers or users. |


## Guild Powerup Rewards
| Code | Message |
| ---- | ------- |
| 690001 | Report not found |
| 690003 | Too many server tag updates. Please try again later. |
| 690008 | Game server name is not allowed |
| 690009 | Game server region is not allowed |
| 690010 | Game server cannot be deactivated during cooldown period |
| 690015 | Invalid SKU type for this operation |
| 690017 | Invalid entitlement metadata |
| 690021 | Server Themes are not enabled for this server. |
| 690025 | Game server hosting is not available |


## Pawtect
| Code | Message |
| ---- | ------- |
| 700000 | USER_GUILD_JOIN_LARGE_GUILD_UNDERAGE_DISALLOWED (UNKNOWN) |


## Checkpoints
| Code | Message |
| ---- | ------- |
| 710000 | Checkpoint not found |
| 710002 | Sorry only humans get a checkpoint. Track your own stats! D:< |
| 710003 | One loot per person! |


## Linking Achivements
| Code | Message |
| ---- | ------- |
| 730000 | Achievement already granted |


## Application Reward Linking
| Code | Message |
| ---- | ------- |
| 740000 | User has not linked their account with this application |


## Partner Connections
| Code | Message |
| ---- | ------- |
| 810000 | This connection provider is deprecated |


## Activity Links
| Code | Message |
| ---- | ------- |
| 5250001 | Activity link not found |